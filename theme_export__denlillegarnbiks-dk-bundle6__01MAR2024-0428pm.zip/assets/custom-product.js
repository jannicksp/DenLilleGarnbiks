document.addEventListener("variant:change", function (event) {
  console.log(event)
})

document.querySelectorAll(".page-btn").forEach((btn) => {
  btn.addEventListener("click", function () {
    const targetId = btn.getAttribute("data-target")
    const slideDiv = document.getElementById(targetId)

    if (slideDiv.classList.contains("tw-show")) {
      slideDiv.classList.remove("tw-show")
      setTimeout(() => {
        slideDiv.classList.add("tw-hidden")
      }, 300) // Match the duration of your transition
    } else {
      slideDiv.classList.remove("tw-hidden")
      // Small delay to allow for content to be visible before transitioning
      setTimeout(() => {
        slideDiv.classList.add("tw-show")
      }, 10)
    }
  })
})

document.querySelectorAll(".ed-option-list").forEach(function (list) {
  list.addEventListener("click", function (e) {
    if (e.target.classList.contains("ed-options")) {
      if (e.target.classList.contains("tw-opacity-40")) {
        return
      }
      // Set all .ed-options in this list to aria-selected="false"
      list.querySelectorAll(".ed-options").forEach(function (item) {
        item.setAttribute("aria-selected", "false")
      })

      // Set clicked .ed-options to aria-selected="true"
      e.target.setAttribute("aria-selected", "true")

      let inputNumber = e.target.dataset.part
      let colorpicker = document.querySelector("span[data-color-" + inputNumber + "]")
      colorpicker.innerHTML = e.target.dataset.title

      document.querySelector("#part-product-" + inputNumber).value = e.target.dataset.variantid
      document.querySelector("img[data-variant-featured-image-" + inputNumber + "]").src =
        event.target.dataset.variantimage
    }
  })
})

const selector = document.querySelector("[data-option-selector]")
// select all label with data-option-value attribute which are childrens of selector
var labels = selector.querySelectorAll("[data-option-value]")

var swatchElement = document.querySelector(":checked + .block-swatch")
var quantities = swatchElement.dataset.quantity.split(",")
// add eventlistener to each label
labels.forEach(function (label) {
  label.addEventListener("click", async function (event) {
    quantities = event.target.dataset.quantity.split(",")
    console.log(quantities)

    // get cart contents get req to /cart.js
    var cart = await getCartContents()
    var cartItems = cart.items
    for (var i = 0; i < quantities.length; i++) {
      document.querySelector("#part-quantity-" + (i + 1)).value = quantities[i]
      document.querySelectorAll("span[data-quantity]")[i].innerHTML = quantities[i] + " stk."
      document.querySelectorAll("#ed-options-list-" + (i + 1) + " li").forEach(function (item) {
        //check if item is in cart and assign the cart item to a variable
        var cartItem = cartItems.find(function (cartItem) {
          return cartItem.variant_id == item.dataset.variantid
        })
        var stockInCart = 0
        // if item is in cart, set inventory to cart item quantity
        if (cartItem) {
          stockInCart = cartItem.quantity
        }

        item.dataset.quantity = quantities[i]

        if (parseInt(item.dataset.inventory) < parseInt(quantities[i]) + parseInt(stockInCart)) {
          // console.log(
          //   "item.dataset.inventory",
          //   item.dataset.inventory,
          //   "item.dataset.title",
          //   item.dataset.title,
          //   "quantities[i]",
          //   quantities[i],
          //   "stockInCart",
          //   stockInCart
          // )
          item.classList.add("tw-opacity-40", "tw-cursor-not-allowed")
        } else {
          item.classList.remove("tw-opacity-40", "tw-cursor-not-allowed")
        }
      })
    }
  })
})

// create a fucntion that logs "test" to the console
async function test() {
  var cart = await getCartContents()
  var cartItems = cart.items
  for (var i = 0; i < quantities.length; i++) {
    document.querySelectorAll("#ed-options-list-" + (i + 1) + " li").forEach(function (item) {
      //check if item is in cart and assign the cart item to a variable
      var cartItem = cartItems.find(function (cartItem) {
        return cartItem.variant_id == item.dataset.variantid
      })
      var stockInCart = 0
      // if item is in cart, set inventory to cart item quantity
      if (cartItem) {
        stockInCart = cartItem.quantity
      }

      item.dataset.quantity = quantities[i]

      //set aria-selected to false
      item.setAttribute("aria-selected", "false")

      if (parseInt(item.dataset.inventory) < parseInt(quantities[i]) + parseInt(stockInCart)) {
        item.classList.add("tw-opacity-40", "tw-cursor-not-allowed")
      } else {
        item.classList.remove("tw-opacity-40", "tw-cursor-not-allowed")
      }
    })
    console.log("testATC")

    for (var i = 0; i < quantities.length; i++) {
      var onlyDefault = document.querySelector("#part-product-" + (i + 1)).dataset.onlydefault
      if (onlyDefault == "false") {
        document.querySelector("#part-product-" + (i + 1)).value = ""
      }
    }
  }
}
window.test = test

async function getCartContents() {
  try {
    const response = await fetch("/cart.json")
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }
    const cartData = await response.json()
    console.log("Cart contents:", cartData)
    return cartData // This is your variable with the cart data
  } catch (error) {
    console.error("Error fetching cart:", error)
  }
}
